PLEASE READ THE FOLLOWING BEFORE CREATING AN ISSUE

This repo exists just to provide an overview of the entire ipfs project and
ecosystem.  If you are about to file an issue about a certain implementation of
ipfs (for example, go-ipfs) Please instead file it in the appropriate location:

For actionable issues pertaining to BUGS in GO-IPFS, create an issue over at:
https://github.com/ipfs/go-ipfs/issues

For QUESTIONS and SUPPORT issues, go to:
https://discuss.ipfs.io

For anything else, please take a look at the project directory on this repos
README.md to find the appropriate location for your issue.
