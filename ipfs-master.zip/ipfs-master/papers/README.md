# papers

These papers have moved to: https://github.com/ipfs/papers

Older versions of the papers are still hosted here to avoid breaking links,
but please update links and refer to the https://github.com/ipfs/papers repo for the most up-to-date versions.
