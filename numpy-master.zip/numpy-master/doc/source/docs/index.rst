.. _documentation:

NumPy's Documentation
=====================

.. toctree::
    :maxdepth: 2

    howto_document
    howto_build_docs
    
