*************************
Old Numeric compatibility
*************************

.. currentmodule:: numpy

The oldnumeric module was removed in NumPy 1.9.0.
