﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ipfs.Lib.Models.Responses
{
    abstract class IpfsResponse
    {
    }
}
