﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ipfs.Lib.Models.Requests
{
    abstract class IpfsRequest
    {
    }
}
