# IpfsCsharpLibrary
A C# library that targets .NET Standard 2.0 that can interact with the IPFS network
