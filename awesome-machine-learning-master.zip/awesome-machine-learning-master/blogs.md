Blogs/Podcasts
===============

[Hacker News for Data Science](http://www.datatau.com/news)

Podcasts
--------

[The O'Reilly Data Show](http://radar.oreilly.com/tag/oreilly-data-show-podcast)

[Partially Derivative](http://partiallyderivative.com/)

[The Talking Machines](http://www.thetalkingmachines.com/)

[The Data Skeptic](https://dataskeptic.com/)

[Linear Digressions](http://benjaffe.github.io/linear-digressions-site/)

[Data Stories](http://datastori.es/)

[Learning Machines 101](http://www.learningmachines101.com/)

[Not So Standard Deviations](http://simplystatistics.org/2015/09/17/not-so-standard-deviations-the-podcast/)

[TWIMLAI](https://twimlai.com/shows/)

[Machine Learning Guide](http://ocdevel.com/podcasts/machine-learning)

Data Science / Statistics
-------------------------

https://ahmedbesbes.com/

https://jeremykun.com/

http://iamtrask.github.io/

http://blog.explainmydata.com/

http://andrewgelman.com/

http://simplystatistics.org/

http://www.evanmiller.org/

http://jakevdp.github.io/

http://blog.yhat.com/

http://wesmckinney.com

http://www.overkillanalytics.net/

http://newton.cx/~peter/

http://mbakker7.github.io/exploratory_computing_with_python/

https://sebastianraschka.com/blog/index.html

http://camdavidsonpilon.github.io/Probabilistic-Programming-and-Bayesian-Methods-for-Hackers/

http://colah.github.io/

http://www.thomasdimson.com/

http://blog.smellthedata.com/

https://sebastianraschka.com/

http://dogdogfish.com/

http://www.johnmyleswhite.com/

http://drewconway.com/zia/

http://bugra.github.io/

http://opendata.cern.ch/

https://alexanderetz.com/

http://www.sumsar.net/

https://www.countbayesie.com

http://karpathy.github.io/  https://medium.com/@karpathy

http://blog.kaggle.com/

http://www.danvk.org/

http://hunch.net/

http://www.randalolson.com/blog/

https://www.johndcook.com/blog/r_language_for_programmers/

http://www.dataschool.io/

http://www.datasciencecentral.com

https://mubaris.com

https://distill.pub

http://blog.shakirm.com/

http://www.cs.ox.ac.uk/people/yarin.gal/website/blog.html

Math
----

http://www.sumsar.net/

http://allendowney.blogspot.ca/

https://healthyalgorithms.com/

https://petewarden.com/

http://mrtz.org/blog/

https://www.youtube.com/channel/UCYO_jab_esuFRV4b17AJtAw/videos

https://www.youtube.com/channel/UCr22xikWUK2yUW4YxOKXclQ/videos

Security Related
----------------

http://jordan-wright.com/blog/
