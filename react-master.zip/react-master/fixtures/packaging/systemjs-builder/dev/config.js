System.config({
  paths: {
    react: '../../../../build/dist/react.development.js',
    'react-dom': '../../../../build/dist/react-dom.development.js',
  },
});
