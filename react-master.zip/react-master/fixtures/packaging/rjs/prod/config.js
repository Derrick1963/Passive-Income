module.exports = {
  baseUrl: '.',
  name: 'input',
  out: 'output.js',
  optimize: 'none',
  paths: {
    react: '../../../../build/dist/react.production.min',
    'react-dom': '../../../../build/dist/react-dom.production.min',
  },
};
