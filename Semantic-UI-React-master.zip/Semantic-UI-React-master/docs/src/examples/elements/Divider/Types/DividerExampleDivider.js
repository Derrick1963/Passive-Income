import React from 'react'
import { Divider } from 'semantic-ui-react'

const DividerExampleDivider = () => <Divider />

export default DividerExampleDivider
