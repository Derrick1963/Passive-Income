import React from 'react'
import Types from './Types'

const FlagExamples = () => (
  <div>
    <Types />
  </div>
)

export default FlagExamples
