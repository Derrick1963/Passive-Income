import React from 'react'
import { Button } from 'semantic-ui-react'

const ButtonExampleNegative = () => (
  <div>
    <Button negative>Negative Button</Button>
  </div>
)

export default ButtonExampleNegative
