import React from 'react'
import { Button } from 'semantic-ui-react'

const ButtonExampleFluid = () => <Button fluid>Fits to Container</Button>

export default ButtonExampleFluid
