import React from 'react'
import { Button } from 'semantic-ui-react'

const ButtonExampleActive = () => <Button active>Active</Button>

export default ButtonExampleActive
