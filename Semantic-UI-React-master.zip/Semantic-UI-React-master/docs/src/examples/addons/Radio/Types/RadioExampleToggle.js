import React from 'react'
import { Radio } from 'semantic-ui-react'

const RadioExampleToggle = () => <Radio toggle />

export default RadioExampleToggle
