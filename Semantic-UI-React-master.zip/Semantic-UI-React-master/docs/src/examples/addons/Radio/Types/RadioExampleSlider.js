import React from 'react'
import { Radio } from 'semantic-ui-react'

const RadioExampleSlider = () => <Radio slider />

export default RadioExampleSlider
