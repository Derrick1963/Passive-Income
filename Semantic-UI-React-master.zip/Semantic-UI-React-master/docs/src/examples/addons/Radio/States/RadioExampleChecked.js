import React from 'react'
import { Radio } from 'semantic-ui-react'

const RadioExampleChecked = () => <Radio label='This radio comes pre-checked' defaultChecked />

export default RadioExampleChecked
