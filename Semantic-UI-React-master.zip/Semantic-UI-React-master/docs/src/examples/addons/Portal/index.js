import React from 'react'
import Types from './Types'

const PortalExamples = () => (
  <div>
    <Types />
  </div>
)

export default PortalExamples
