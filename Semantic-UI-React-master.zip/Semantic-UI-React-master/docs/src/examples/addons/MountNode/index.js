import React from 'react'
import Types from './Types'

const MountNodeExamples = () => (
  <div>
    <Types />
  </div>
)

export default MountNodeExamples
