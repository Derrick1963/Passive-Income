import React from 'react'
import { Message } from 'semantic-ui-react'

const MessageExampleFloating = () => <Message floating>Way to go!</Message>

export default MessageExampleFloating
